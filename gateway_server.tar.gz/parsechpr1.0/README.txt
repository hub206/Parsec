Parsec High Performance Relay (HPR)
-----------------------------------

The Parsec High Performance Relay (HPR) is a lightweight server program that allows
efficient relaying of many simultaneous Parsec connections through a single IP address /
port configuration. It can be used to assist with NAT traversal as either an on-premises
gateway for large LAN deployments of Parsec, or as a general purpose WAN relay server.


Usage
-----

parsechpr [public_address] [public_port] [private_port]

The HPR will bind to all interfaces with both [public_port] and [private_port]. The
[public_address]:[public_port] will be communicated to peers that need to route through
the HPR and must be accessible from the WAN.

[private_port] may be configured for additional security. Using a [private_port] ensures
that relay requests can only be originated on the [private_port] specified, and any relay
requests attempting to be originated on [public_port] will be dropped. If [public_port]
is the same as [private_port], only a single port will be used.

Beginning with Parsec build 150-48, the STUN server address may be specified in the
configuration file via app_stun_address:

app_stun_address = 192.168.1.150@[private_port]   # Use a local address if possible

An '@' character must be used to delimit the IP address and port. Up to 10 address@port
pairs may be configured, separated by commas:

app_stun_address = 192.168.1.150@23050,192.168.1.151@23051,...

If more than one STUN server is available, Parsec will choose a STUN server at random on
each connection attempt. If an attempt fails beacuse the STUN address could not be
reached, Parsec will blacklist that address for 10 minutes and only consider the
remaining addresses.

The HPR acts as a phony STUN server that exposes itself as the peer's address rather than
the true public IP. This will cause Parsec to route all WAN traffic through the HPR
instead of using its normal NAT traversal routines.


Installation
------------

This archive comes with an example systemd service named parsechpr.service. First, modify
the service to use the correct address/port information:

ExecStart=/bin/parsechpr 1.2.3.4 5000 4900   # Use your correct address information

The HPR can then be set up to start on boot:

cp parsechpr /bin
cp parsechpr.service /etc/systemd/system
systemctl start parsechpr
systemctl enable parsechpr


Details
-------

The HPR lightly inspects packets sent to both its [public_port] and [private_port]. It
maintains a ~128MB static lookup table used to pair two Parsec peers at connection time.

For the purpose of this document, the Parsec peer using the HPR will be labeled "P1" and
the peer attempting to connect to P1 will be labeled "P2".

1. P1 configures itself to use the HPR by setting "app_stun_address" and "app_stun_port"
   in the configuration file.

2. P2 initiates a connection to P1, then the two peers exchange an unguessable 8 byte
   pairing key via Parsec's secure websocket.

3. P1 makes a STUN Binding Request to the HPR via the secure [private_port]:
   a. The HPR uses the pairing key included in the STUN Binding Request to originate
      the pairing request by creating an entry in the internal lookup tables.
   b. The HPR returns the [public_address]:[public_port] to P1 as its WAN candidate.

4. P1 sends its WAN candidate, now the HPR's [public_address]:[public_port], to P2.

5. P2 sends a STUN Binding Request to the HPR which includes the pairing key.

6. If the pairing key sent from P2 matches P1's key in the lookup table, the peers
   become paired and UDP traffic begins to flow via the HPR.

7. All STUN protocol packets continue to be integrity checked via a private key never
   sent over the wire (see WebRTC). Packets that arrive to the Parsec app that do not
   pass the integrity check are dropped.

8. All other BUD/SCTP packets that may arrive are fully encrypted via AES128-GCM.
   Packets that fail decryption or the GCM authentication check are dropped.

9. All entries in the internal lookup tables are invalidated after 2 minutes of no
   traffic.
